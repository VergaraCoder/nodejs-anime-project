const fs = require('fs');
const path = require('path');

const rutaAbsoluta = path.join(__dirname, '../../data/animes.json');


function detectarIdRepetidas(id, data) {
    let idMayor = id;
    for (x of data) {
        if (x.id > idMayor) {
            idMayor = x.id;
        }
    }
    idMayor++;
    return idMayor;
}



function readData(ruta) {
    return new Promise((resolve, reject) => {
        fs.readFile(ruta, "utf-8", (err, data) => {
            if (err) {
                reject(new Error("NO SE PUDO LEER EL ARCHIVO"));
            } else {
                resolve(JSON.parse(data));
            }
        });
    });
}

function writeData(ruta, data) {
    return new Promise((resolve, reject) => {
        fs.writeFile(ruta, data, (err) => {
            if (err) {
                reject(new Error("NO SE PUDO ESCRIBIR SOBRE EL ARCHIVO"));
            } else {
                resolve("Melo");
            }
        });
    });
}

async function addData(newData, segmento) {
    try {
        const data = await readData(rutaAbsoluta);

        const idRegister = detectarIdRepetidas(data[segmento].length, data[segmento]);

        newData.id = idRegister;

        data[segmento].push(newData);

        await writeData(rutaAbsoluta, JSON.stringify(data));
        return newData;
    }
    catch (err) {
        console.log(err.message);
    }
}



async function updateData(idData, updateData, segmento) {
    try {
        const data = await readData(rutaAbsoluta);
        const indiceData = data[segmento].findIndex(item => {
            return item.id == idData;
        })
        if (indiceData === -1) { return false }

        else {
            data[segmento][indiceData] = { id: idData, ...updateData };
            await writeData(rutaAbsoluta, JSON.stringify(data));
            return true;
        }
    }
    catch (err) {
        err.message
    }
}



module.exports = { addData, rutaAbsoluta, readData, updateData, writeData }