const express = require('express');
const { addData, rutaAbsoluta, readData, updateData, writeData } = require('../functions/functions');
const { write } = require('fs');




const router = express.Router();


router.get("/", (req, res) => {
    res.send(`<form method="post" action="/login">
        <input type="text" name="username">
        <input type="text" name="password" >
        <input type="submit">
    </form>`);
});

router.post("/login", (req, res) => {
    console.log(req.body);
    res.send("Ya estas en el formularop");
});

// RUTA ANIMES

router.post("/animes", async (req, res) => {
    try {
        const response = await addData(req.body, "anime");
        res.status(200).json({
            message: "anime agregado con exito",
            anime: response
        });
    }
    catch (err) {
        res.status(401).json({
            message: "NO SE PUDO AGREGAR EL OBJETO"
        });
    }
});


router.get("/animes", async (req, res) => {
    try {
        const data = await readData(rutaAbsoluta);
        res.status(200).json({
            animes: data.anime
        })
    }
    catch (err) {
        res.json({ message: err.message });
    }
});


router.get("/animes/:id", async (req, res) => {
    try {
        const id = req.params.id;
        const data = await readData(rutaAbsoluta);
        const response = data.anime.find(item => { return item.id == parseInt(id) });

        console.log(response);
        if (!response) throw new Error("NO HAY NINGUN RESGITRO DE ALGUN ANIME CON ESE ID");

        else res.status(200).json({
            anime: response

        })
    }
    catch (err) {
        res.status(404).json({ message: err.message });
    }
});


router.put("/animes/:id", async (req, res) => {
    try {
        const anime = await updateData(parseInt(req.params.id), req.body, "anime");

        if (!anime) throw new Error("NO SE PUDO ACTUALIZAR EL OBJETO");

        else {
            res.status(200).json({ message: "actualizado exitosamente" })
        };
    }
    catch (err) {
        res.status(404).json({ message: err.message })
    }
});


router.delete("/animes/:id", async (req, res) => {
    try {
        const data = await readData(rutaAbsoluta);
        const indice = data.anime.findIndex(item => {
            return item.id === parseInt(req.params.id);
        });

        if (indice === -1) throw new Error("NO EXISTE NINGUN ANIME CON ESE ID");
        else {
            data.anime.splice(indice, 1);
            await writeData(rutaAbsoluta, JSON.stringify(data));
            res.status(200).json({ message: "Anime eliminado exitosamente" })
        }
    }
    catch (err) {
        res.status(404).json({ message: err.message });
    }
});




//RUTA STUDIOS

router.post("/studios", async (req, res) => {
    try {
        const response = await addData(req.body, "studios");
        res.status(200).json({
            message: "Studio agregado con exito",
            studio: response
        });
    }
    catch (err) {
        res.status(401).json({
            message: "NO SE PUDO AGREGAR EL OBJETO"
        });
    }
});


router.get("/studios", async (req, res) => {
    try {
        const data = await readData(rutaAbsoluta);
        res.status(200).json({
            studios: data.studios
        })
    }
    catch (err) {
        res.json({ message: err.message });
    }
});


router.get("/studios/:id", async (req, res) => {
    try {
        console.log("ENTRAO");
        const id = req.params.id;
        const data = await readData(rutaAbsoluta);
        const response = data.studios.find(item => { return item.id == parseInt(id) });

        if (!response) throw new Error("NO HAY NINGUN RESGITRO DE ALGUN STUDIO CON ESE ID");

        else res.status(200).json({
            studio: response
        })
    }
    catch (err) {
        res.status(404).json({ message: err.message });
    }
});


router.put("/studios/:id", async (req, res) => {
    try {
        const studio = await updateData(parseInt(req.params.id), req.body, "studios");

        if (!studio) throw new Error("NO SE PUDO ACTUALIZAR EL OBJETO");

        else {
            res.status(200).json({ message: "actualizado exitosamente" })
        };
    }
    catch (err) {
        res.status(404).json({ message: err.message })
    }
});



router.delete("/studios/:id", async (req, res) => {
    try {
        const data = await readData(rutaAbsoluta);
        const indice = data.studios.findIndex(item => {
            return item.id === parseInt(req.params.id);
        });

        if (indice === -1) throw new Error("NO EXISTE NINGUN STUDIO CON ESE ID");
        else {
            data.studios.splice(indice, 1);
            await writeData(rutaAbsoluta, JSON.stringify(data));
            res.status(200).json({ message: "studio eliminado exitosamente" })
        }
    }
    catch (err) {
        res.status(404).json({ message: err.message });
    }
});





// RUTA DIRECTORS

router.post("/directors", async (req, res) => {
    try {
        const response = await addData(req.body, "directors");
        res.status(200).json({
            message: "Director agregado con exito",
            anime: response
        });
    }
    catch (err) {
        res.status(401).json({
            message: "NO SE PUDO AGREGAR EL OBJETO"
        });
    }
});


router.get("/directors", async (req, res) => {
    try {
        const data = await readData(rutaAbsoluta);
        res.status(200).json({
            directores: data.directors
        })
    }
    catch (err) {
        res.json({ message: err.message });
    }
});

router.get("/directors/:id", async (req, res) => {
    try {
        const id = req.params.id;
        const data = await readData(rutaAbsoluta);
        const response = data.directors.find(item => { return item.id == parseInt(id) });

        console.log(response);
        if (!response) throw new Error("NO HAY NINGUN RESGITRO DE ALGUN ANIME CON ESE ID");

        else res.status(200).json({
            director: response

        })
    }
    catch (err) {
        res.status(404).json({ message: err.message });
    }
});


router.put("/directors/:id", async (req, res) => {
    try {
        const director = await updateData(parseInt(req.params.id), req.body, "directors");

        if (!director) throw new Error("NO SE PUDO ACTUALIZAR EL OBJETO");

        else {
            res.status(200).json({ message: "actualizado exitosamente" })
        };
    }
    catch (err) {
        res.status(404).json({ message: err.message })
    }
});


router.delete("/directors/:id", async (req, res) => {
    try {
        const data = await readData(rutaAbsoluta);
        const indice = data.directors.findIndex(item => {
            return item.id === parseInt(req.params.id);
        });

        if (indice === -1) throw new Error("NO EXISTE NINGUN STUDIO CON ESE ID");
        else {
            data.directors.splice(indice, 1);
            await writeData(rutaAbsoluta, JSON.stringify(data));
            res.status(200).json({ message: "Director eliminado exitosamente" })
        }
    }
    catch (err) {
        res.status(404).json({ message: err.message });
    }
});





// RUTAS CHARACTER

router.post("/characters", async (req, res) => {
    try {
        const response = await addData(req.body, "characters");
        res.status(200).json({
            message: "character agregado con exito",
            characters: response
        });
    }
    catch (err) {
        res.status(401).json({
            message: "NO SE PUDO AGREGAR EL OBJETO"
        });
    }
});


router.get("/characters", async (req, res) => {
    try {
        const data = await readData(rutaAbsoluta);
        res.status(200).json({
            characters: data.characters
        })
    }
    catch (err) {
        res.json({ message: err.message });
    }
});

router.get("/characters/:id", async (req, res) => {
    try {
        const id = req.params.id;
        const data = await readData(rutaAbsoluta);
        const response = data.characters.find(item => { return item.id == parseInt(id) });

        console.log(response);
        if (!response) throw new Error("NO HAY NINGUN RESGITRO DE ALGUN ANIME CON ESE ID");

        else res.status(200).json({
            characters: response

        })
    }
    catch (err) {
        res.status(404).json({ message: err.message });
    }
});


router.put("/characters/:id", async (req, res) => {
    try {
        const characters = await updateData(parseInt(req.params.id), req.body, "characters");

        if (!characters) throw new Error("NO SE PUDO ACTUALIZAR EL OBJETO");

        else {
            res.status(200).json({ message: "actualizado exitosamente" })
        };
    }
    catch (err) {
        res.status(404).json({ message: err.message })
    }
});


router.delete("/characters/:id", async (req, res) => {
    try {
        const data = await readData(rutaAbsoluta);
        const indice = data.characters.findIndex(item => {
            return item.id === parseInt(req.params.id);
        });

        if (indice === -1) throw new Error("NO EXISTE NINGUN STUDIO CON ESE ID");
        else {
            data.characters.splice(indice, 1);
            await writeData(rutaAbsoluta, JSON.stringify(data));
            res.status(200).json({ message: "character eliminado exitosamente" })
        }
    }
    catch (err) {
        res.status(404).json({ message: err.message });
    }
});

module.exports = { router }